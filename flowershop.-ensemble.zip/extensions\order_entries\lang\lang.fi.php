<?php

	$about = array(
		'name' => 'Finnish',
		'author' => array(
			'name' => 'Leo Nikkilä',
			'email' => 'hello@lnikki.la',
			'website' => 'https://lnikki.la'
		),
		'release-date' => '2013-06-22'
	);

	/**
	 * Order Entries
	 */
	$dictionary = array(

		'Entry order saved.' => 
		'Järjestys tallennettu.',

		'Entry Order' => 
		'Merkintöjen järjestys',
		
		'%s Disable sorting of other columns when enabled' => 
		'%s Estä muiden sarakkeiden perusteella järjestäminen',

		'%s Hide this field on publish page' => 
		'%s Piilota tämä kenttä muokkaussivulla',
		
		'drag to reorder' =>
		'järjestä uudelleen raahaamalla rivejä'
		
	);
