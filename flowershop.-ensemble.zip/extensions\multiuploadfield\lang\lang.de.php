<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => 'Büro für Web- und Textgestaltung',
			'email' => 'buero@hananils.de',
			'website' => 'http://hananils.de'
		),
		'release-date' => '2013-10-21'
	);

	/**
	 * Multi Upload Field
	 */
	$dictionary = array(

		'Drop files' => 
		'Dateien hinzufügen',

		'In queue' => 
		'In der Warteschleife',

		'Remove file' => 
		'Datei entfernen',

		'Upload failed' => 
		'Hochladen fehlgeschlagen',

		'Add file' => 
		'Datei hinzufügen',

		'The file, %s, is no longer available. Please check that it exists, and is readable.' => 
		'Die Datei %s is nicht mehr verfügbar. Bitte überprüfen Sie ob sie existiert und lesbar ist.',

	);
