$('#slides').unslider({
	keys: false, arrows: false, nav: false, autoplay : true
});