<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Андрей Лубинов',
			'email' => 'andrey.lubinov@gmail.com',
			'website' => ''
		),
		'release-date' => '2011-02-09'
	);

	/**
	 * Order Entries
	 */
	$dictionary = array(
	
		'drag to reorder' =>
		'перетягивайте записи мышкой, чтобы отсортировать',

		'Entry order saved.' =>
		false,

		'Entry Order' =>
		false,

		'%s Disable sorting of other columns when enabled' =>
		false,

		'%s Hide this field on publish page' =>
		false,

	);
