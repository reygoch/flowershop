<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Александр Бирюков',
			'email' => 'info@alexbirukov.ru',
			'website' => 'http://alexbirukov.ru'
		),
		'release-date' => '2013-01-20'
	);

	/**
	 * Number Field
	 */
	$dictionary = array(

		'Number' => 
		'Число',

		'Must be a number.' => 
		'Укажите корректное число.',

	);
