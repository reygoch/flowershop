<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => 'Nils Hörrmann',
			'email' => 'post@nilshoerrmann.de',
			'website' => 'http://www.nilshoerrmann.de'
		),
		'release-date' => '2013-09-18'
	);

	/**
	 * Select Box Link Field
	 */
	$dictionary = array(

		'Allow selection of multiple options' => 
		'Erlaube Mehrfachauswahl.',

		'Select Box Link' => 
		'Select Box Link',

		'Values' => 
		'Werte',

		'Limit to %s entries' => 
		'Auf %s Einträge beschränken',

		'Hide when prepopulated' => 
		'Vorausgefüllte Felder verstecken',

	);
