<?php

    class migration_224 extends Migration
    {
        public static function getVersion()
        {
            return '2.2.4';
        }

        public static function getReleaseNotes()
        {
            return 'http://getsymphony.com/download/releases/version/2.2.4/';
        }
    }
