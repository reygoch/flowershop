<?php

	$about = array(
		'name' => 'Polish',
		'author' => array(
			'name' => 'Admin IDEA07',
			'email' => 'admin@idea07.pl',
			'website' => ''
		),
		'release-date' => '2013-06-20'
	);

	/**
	 * Order Entries
	 */
	$dictionary = array(

		// Missing

		'drag to reorder' => 
		'przeciągnij aby zmienić kolejność',

		'Entry order saved.' => 
		'Kolejność wpisu zapisana',

		'Entry Order' => 
		'Entry Order',

		'%s Disable sorting of other columns when enabled' => 
		'%s Wyłącz sortowanie innych kolumn gdy włączone',

		'%s Hide this field on publish page' => 
		'%s Ukryj to pole na stronie publikowania',

		'To filter by ranges, add <code>%s</code> to the beginning of the filter input. Use <code>%s</code> for field name. E.G. <code>%s</code>' => 
		'Aby filtrować po zakresach, dodaj <code>%s</code> na początku pola filtrowania. Użyj <code>%s</code> dla nazy pola. Np. <code>%s</code>',

		'Must be a number.' => 
		'Musi być liczbą',

	);
