<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => 'Nils Hörrmann, Alexander Rutz',
			'email' => 'post@nilshoerrmann.de, ar@animaux.de',
			'website' => ''
		),
		'release-date' => '2014-10-29'
	);

	/**
	 * Order Entries
	 */
	$dictionary = array(

		'Entry order saved.' => 
		'Sortierreihenfolge gespeichert.',

		'Entry Order' => 
		'Sortierreihenfolge',

		'%s Hide this field on publish page' => 
		'%s Dieses Feld in der Einzelansicht verbergen',
		
		'drag to reorder' =>
		'zum Sortieren Einträge verschieben',
		
		'%s Force manual sorting' =>
		'%s Manuelle Sortierung erzwingen',
		
		'%s Hide on publish page' =>
		'%s Dieses Feld in der Einzelansicht verbergen'
		
	);
