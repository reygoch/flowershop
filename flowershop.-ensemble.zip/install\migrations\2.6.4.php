<?php

    class migration_264 extends Migration
    {
        public static function getVersion()
        {
            return '2.6.4';
        }

        public static function getReleaseNotes()
        {
            return 'http://getsymphony.com/download/releases/version/2.6.4/';
        }
    }
