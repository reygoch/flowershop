<?php

	$recipes = array(

		########
		array(
			'mode' => '2',
			'name' => 'Slider',
			'url-parameter' => 'slider',
			'width' => '880',
			'height' => '350',
			'position' => '5',
			'background' => NULL,
			'quality' => NULL,
			'external' => '0',
		),
		########

		########
		array(
			'mode' => '2',
			'name' => 'Preview',
			'url-parameter' => 'preview',
			'width' => '100',
			'height' => '100',
			'position' => '5',
			'background' => NULL,
			'quality' => NULL,
			'external' => '0',
		),
		########

		########
		array(
			'mode' => '2',
			'name' => 'Main Image',
			'url-parameter' => 'main-image',
			'width' => '300',
			'height' => '300',
			'position' => '5',
			'background' => NULL,
			'quality' => NULL,
			'external' => '0',
		),
		########

		########
		array(
			'mode' => '2',
			'name' => 'Gallery Thumbnail',
			'url-parameter' => 'gallery-thumb',
			'width' => '100',
			'height' => '100',
			'position' => '5',
			'background' => NULL,
			'quality' => NULL,
			'external' => '0',
		),
		########

		########
		array(
			'mode' => '1',
			'name' => 'Gallery Full Size',
			'url-parameter' => 'gallery-image',
			'width' => '600',
			'height' => '0',
			'quality' => NULL,
			'external' => '0',
		),
		########

	);
