<?php

	$about = array(
		'name' => 'Slovensky',
		'author' => array(
			'name' => 'Juraj Kapsz',
			'email' => 'info@jurajkapsz.sk',
			'website' => 'http://jurajkapsz.sk'
		),
		'release-date' => '2015-04-22'
	);

	/**
	 * HTML5 Doctype
	 */
	$dictionary = array(

		'Exclude Types' =>
		'Ignorovať typy stránok',

	);
